
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.lucas.world.features.ores.JumpblockFeature;
import net.mcreator.lucas.LucasMod;

@Mod.EventBusSubscriber
public class LucasModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, LucasMod.MODID);
	public static final RegistryObject<Feature<?>> JUMPBLOCK = REGISTRY.register("jumpblock", JumpblockFeature::new);
}
