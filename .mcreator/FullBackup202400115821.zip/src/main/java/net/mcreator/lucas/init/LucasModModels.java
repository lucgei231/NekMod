
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.mcreator.lucas.client.model.Modelsupersheep;
import net.mcreator.lucas.client.model.Modeldumbcar;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class LucasModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modeldumbcar.LAYER_LOCATION, Modeldumbcar::createBodyLayer);
		event.registerLayerDefinition(Modelsupersheep.LAYER_LOCATION, Modelsupersheep::createBodyLayer);
	}
}
