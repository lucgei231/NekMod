package net.mcreator.lucas.procedures;

import net.mcreator.lucas.network.LucasModVariables;

public class GKeyFalseProcedure {
	public static void execute(LevelAccessor world) {
		LucasModVariables.MapVariables.get(world).gkeypressed = false;
		LucasModVariables.MapVariables.get(world).syncData(world);
	}
}
