package net.mcreator.lucas.procedures;

import net.minecraftforge.eventbus.api.Event;

@Mod.EventBusSubscriber
public class LightningswordLivingEntityIsHitWithToolProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event);
		}
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
	}
}
