package net.mcreator.lucas.procedures;

import java.util.Calendar;

public class IridiumoreRedstoneOnProcedure {
	public static void execute() {
		double time = 0;
		BlockState time2 = Blocks.AIR.defaultBlockState();
		time = Calendar.getInstance().get(Calendar.SECOND);
	}
}
