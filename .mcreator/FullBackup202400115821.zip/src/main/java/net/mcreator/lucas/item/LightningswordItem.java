
package net.mcreator.lucas.item;

import net.mcreator.lucas.procedures.LightningswordRightclicked1Procedure;
import net.mcreator.lucas.procedures.LightningswordEntitySwingsItemProcedure;

public class LightningswordItem extends SwordItem {
	public LightningswordItem() {
		super(new Tier() {
			public int getUses() {
				return 128;
			}

			public float getSpeed() {
				return 4f;
			}

			public float getAttackDamageBonus() {
				return 87f;
			}

			public int getLevel() {
				return 10;
			}

			public int getEnchantmentValue() {
				return 99;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 3, 16f, new Item.Properties().fireResistant());
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		LightningswordRightclicked1Procedure.execute(entity);
		return ar;
	}

	@Override
	public boolean onEntitySwing(ItemStack itemstack, LivingEntity entity) {
		boolean retval = super.onEntitySwing(itemstack, entity);
		LightningswordEntitySwingsItemProcedure.execute(entity.level(), entity);
		return retval;
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}
