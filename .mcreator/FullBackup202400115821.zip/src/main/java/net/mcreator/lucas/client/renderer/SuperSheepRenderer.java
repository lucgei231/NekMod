
package net.mcreator.lucas.client.renderer;

import net.mcreator.lucas.entity.SuperSheepEntity;
import net.mcreator.lucas.client.model.Modelsupersheep;

public class SuperSheepRenderer extends MobRenderer<SuperSheepEntity, Modelsupersheep<SuperSheepEntity>> {
	public SuperSheepRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelsupersheep(context.bakeLayer(Modelsupersheep.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(SuperSheepEntity entity) {
		return new ResourceLocation("lucas:textures/entities/supersheeptexturenew.png");
	}
}
