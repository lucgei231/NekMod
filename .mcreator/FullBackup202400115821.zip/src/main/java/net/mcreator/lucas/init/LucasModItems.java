
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.mcreator.lucas.item.LightningswordItem;
import net.mcreator.lucas.item.IrItem;
import net.mcreator.lucas.LucasMod;

public class LucasModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LucasMod.MODID);
	public static final RegistryObject<Item> HELLO_BABY = block(LucasModBlocks.HELLO_BABY);
	public static final RegistryObject<Item> JUMPBLOCK = block(LucasModBlocks.JUMPBLOCK);
	public static final RegistryObject<Item> FIREBALL_SWORD = REGISTRY.register("fireball_sword", () -> new LightningswordItem());
	public static final RegistryObject<Item> FIREBLOCK = block(LucasModBlocks.FIREBLOCK);
	public static final RegistryObject<Item> BIGFIRE = block(LucasModBlocks.BIGFIRE);
	public static final RegistryObject<Item> IRIDIUMORE = block(LucasModBlocks.IRIDIUMORE);
	public static final RegistryObject<Item> IR = REGISTRY.register("ir", () -> new IrItem());
	public static final RegistryObject<Item> SHEEP_MOB_1_SPAWN_EGG = REGISTRY.register("sheep_mob_1_spawn_egg", () -> new ForgeSpawnEggItem(LucasModEntities.SHEEP_MOB_1, -65332, -3342388, new Item.Properties()));
	public static final RegistryObject<Item> SUPER_SHEEP_SPAWN_EGG = REGISTRY.register("super_sheep_spawn_egg", () -> new ForgeSpawnEggItem(LucasModEntities.SUPER_SHEEP, -1, -16711834, new Item.Properties()));
	public static final RegistryObject<Item> LOOCLOUD = block(LucasModBlocks.LOOCLOUD);
	public static final RegistryObject<Item> DUMB_BUTT_LOO_PLANT = block(LucasModBlocks.DUMB_BUTT_LOO_PLANT);
	public static final RegistryObject<Item> DUMBCAR_SPAWN_EGG = REGISTRY.register("dumbcar_spawn_egg", () -> new ForgeSpawnEggItem(LucasModEntities.DUMBCAR, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
