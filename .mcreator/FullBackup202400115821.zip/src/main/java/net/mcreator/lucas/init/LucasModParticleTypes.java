
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.mcreator.lucas.LucasMod;

public class LucasModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, LucasMod.MODID);
	public static final RegistryObject<SimpleParticleType> LOO = REGISTRY.register("loo", () -> new SimpleParticleType(false));
}
