package net.mcreator.lucas.procedures;

import net.mcreator.lucas.network.LucasModVariables;

public class GKeyTrueProcedure {
	public static void execute(LevelAccessor world) {
		LucasModVariables.MapVariables.get(world).gkeypressed = true;
		LucasModVariables.MapVariables.get(world).syncData(world);
	}
}
