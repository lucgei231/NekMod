
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.lucas.LucasMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LucasModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LucasMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(LucasModBlocks.JUMPBLOCK.get().asItem());
			tabData.accept(LucasModBlocks.FIREBLOCK.get().asItem());
			tabData.accept(LucasModBlocks.BIGFIRE.get().asItem());
		}

		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(LucasModItems.FIREBALL_SWORD.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LucasModItems.SHEEP_MOB_1_SPAWN_EGG.get());
			tabData.accept(LucasModItems.SUPER_SHEEP_SPAWN_EGG.get());
			tabData.accept(LucasModItems.DUMBCAR_SPAWN_EGG.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(LucasModBlocks.IRIDIUMORE.get().asItem());
			tabData.accept(LucasModItems.IR.get());
			tabData.accept(LucasModBlocks.LOOCLOUD.get().asItem());
		}

		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(LucasModBlocks.HELLO_BABY.get().asItem());
		}

		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(LucasModBlocks.DUMB_BUTT_LOO_PLANT.get().asItem());
		}
	}
}
