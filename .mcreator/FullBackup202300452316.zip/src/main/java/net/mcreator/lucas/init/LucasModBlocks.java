
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.lucas.block.LoocloudBlock;
import net.mcreator.lucas.block.JumpblockBlock;
import net.mcreator.lucas.block.IridiumoreBlock;
import net.mcreator.lucas.block.HelloBabyBlock;
import net.mcreator.lucas.block.FireblockBlock;
import net.mcreator.lucas.block.DumbButtLooPlantBlock;
import net.mcreator.lucas.block.BigfireBlock;
import net.mcreator.lucas.LucasMod;

public class LucasModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, LucasMod.MODID);
	public static final RegistryObject<Block> JUMPBLOCK = REGISTRY.register("jumpblock", () -> new JumpblockBlock());
	public static final RegistryObject<Block> HELLO_BABY = REGISTRY.register("hello_baby", () -> new HelloBabyBlock());
	public static final RegistryObject<Block> FIREBLOCK = REGISTRY.register("fireblock", () -> new FireblockBlock());
	public static final RegistryObject<Block> BIGFIRE = REGISTRY.register("bigfire", () -> new BigfireBlock());
	public static final RegistryObject<Block> IRIDIUMORE = REGISTRY.register("iridiumore", () -> new IridiumoreBlock());
	public static final RegistryObject<Block> LOOCLOUD = REGISTRY.register("loocloud", () -> new LoocloudBlock());
	public static final RegistryObject<Block> DUMB_BUTT_LOO_PLANT = REGISTRY.register("dumb_butt_loo_plant", () -> new DumbButtLooPlantBlock());
}
