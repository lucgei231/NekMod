
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.lucas.entity.SuperSheepEntity;
import net.mcreator.lucas.entity.SheepMob1Entity;
import net.mcreator.lucas.entity.DumbcarEntity;
import net.mcreator.lucas.LucasMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LucasModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, LucasMod.MODID);
	public static final RegistryObject<EntityType<SheepMob1Entity>> SHEEP_MOB_1 = register("sheep_mob_1",
			EntityType.Builder.<SheepMob1Entity>of(SheepMob1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(50).setUpdateInterval(3).setCustomClientFactory(SheepMob1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SuperSheepEntity>> SUPER_SHEEP = register("super_sheep",
			EntityType.Builder.<SuperSheepEntity>of(SuperSheepEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(99).setUpdateInterval(3).setCustomClientFactory(SuperSheepEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<DumbcarEntity>> DUMBCAR = register("dumbcar",
			EntityType.Builder.<DumbcarEntity>of(DumbcarEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DumbcarEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SheepMob1Entity.init();
			SuperSheepEntity.init();
			DumbcarEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SHEEP_MOB_1.get(), SheepMob1Entity.createAttributes().build());
		event.put(SUPER_SHEEP.get(), SuperSheepEntity.createAttributes().build());
		event.put(DUMBCAR.get(), DumbcarEntity.createAttributes().build());
	}
}
