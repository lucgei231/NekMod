package net.mcreator.lucas.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;

public class IridiumoreBlockDestroyedByPlayerProcedure {
	public static boolean eventResult = true;

	public IridiumoreBlockDestroyedByPlayerProcedure() {
		ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
			execute(sender.level(), sender);
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		double babby = 0;
		babby = Mth.nextInt(RandomSource.create(), 1, 10);
		if (babby == 6) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("ORE++"), false);
			}
		} else if (babby == 5) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("ORE+"), false);
			}
		} else {
		}
		babby = Mth.nextInt(RandomSource.create(), 1, 10);
	}
}