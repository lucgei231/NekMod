package net.mcreator.lucas.world.features.treedecorators;

import net.minecraft.world.level.levelgen.feature.treedecorators.TreeDecoratorType;
import net.minecraft.world.level.levelgen.feature.treedecorators.TreeDecorator;
import net.minecraft.world.level.levelgen.feature.treedecorators.CocoaDecorator;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.CocoaBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.util.RandomSource;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import com.mojang.serialization.MapCodec;

public class CandylandFruitDecorator extends CocoaDecorator {
	public static MapCodec<CandylandFruitDecorator> CODEC = MapCodec.unit(CandylandFruitDecorator::new);
	public static TreeDecoratorType<?> DECORATOR_TYPE = new TreeDecoratorType<>(CODEC);

	public CandylandFruitDecorator() {
		super(0.2f);
	}

	@Override
	protected TreeDecoratorType<?> type() {
		return DECORATOR_TYPE;
	}

	@Override
	public void place(TreeDecorator.Context context) {
		RandomSource randomSource = context.random();
		if (randomSource.nextFloat() >= 0.2F) {
			return;
		}
		ObjectArrayList<BlockPos> list = context.logs();
		if (list.isEmpty()) {
			return;
		}
		int i = ((BlockPos) list.getFirst()).getY();
		list.stream().filter(blockPos -> blockPos.getY() - i <= 2).forEach(blockPos -> {
			for (Direction direction : Direction.Plane.HORIZONTAL) {
				Direction direction2;
				BlockPos blockPos2;
				if (!(randomSource.nextFloat() <= 0.25f) || !context.isAir(blockPos2 = blockPos.offset((direction2 = direction.getOpposite()).getStepX(), 0, direction2.getStepZ())))
					continue;
				context.setBlock(blockPos2, (BlockState) ((BlockState) Blocks.COCOA.defaultBlockState().setValue(CocoaBlock.AGE, randomSource.nextInt(3))).setValue(CocoaBlock.FACING, direction));
			}
		});
	}

	@SuppressWarnings("deprecation")
	private static BlockState oriented(BlockState blockstate, Direction direction) {
		return switch (direction) {
			case SOUTH -> blockstate.rotate(Rotation.CLOCKWISE_180);
			case EAST -> blockstate.rotate(Rotation.CLOCKWISE_90);
			case WEST -> blockstate.rotate(Rotation.COUNTERCLOCKWISE_90);
			default -> blockstate;
		};
	}
}