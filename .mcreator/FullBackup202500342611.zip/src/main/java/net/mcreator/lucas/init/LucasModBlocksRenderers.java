/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.mcreator.lucas.block.LoocloudBlock;
import net.mcreator.lucas.block.FireblockBlock;
import net.mcreator.lucas.block.DumbButtLooPlantBlock;
import net.mcreator.lucas.block.BigfireBlock;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class LucasModBlocksRenderers {
	public static void clientLoad() {
		FireblockBlock.registerRenderLayer();
		BigfireBlock.registerRenderLayer();
		LoocloudBlock.registerRenderLayer();
		DumbButtLooPlantBlock.registerRenderLayer();
	}
	// Start of user code block custom block renderers
	// End of user code block custom block renderers
}