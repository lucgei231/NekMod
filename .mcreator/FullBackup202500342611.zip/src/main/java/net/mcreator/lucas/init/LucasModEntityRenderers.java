/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.mcreator.lucas.client.renderer.SuperSheepRenderer;
import net.mcreator.lucas.client.renderer.SheepMob1Renderer;
import net.mcreator.lucas.client.renderer.DumbcarRenderer;

import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class LucasModEntityRenderers {
	public static void clientLoad() {
		EntityRendererRegistry.register(LucasModEntities.SHEEP_MOB_1, SheepMob1Renderer::new);
		EntityRendererRegistry.register(LucasModEntities.SUPER_SHEEP, SuperSheepRenderer::new);
		EntityRendererRegistry.register(LucasModEntities.DUMBCAR, DumbcarRenderer::new);
	}
}