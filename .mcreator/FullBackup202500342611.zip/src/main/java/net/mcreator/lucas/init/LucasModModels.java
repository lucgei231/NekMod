/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.mcreator.lucas.client.model.Modelsupersheep;
import net.mcreator.lucas.client.model.Modeldumbcar;

import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class LucasModModels {
	public static void clientLoad() {
		EntityModelLayerRegistry.registerModelLayer(Modeldumbcar.LAYER_LOCATION, Modeldumbcar::createBodyLayer);
		EntityModelLayerRegistry.registerModelLayer(Modelsupersheep.LAYER_LOCATION, Modelsupersheep::createBodyLayer);
	}
}