package net.mcreator.lucas;

import net.mcreator.lucas.network.LucasModVariables;
import net.mcreator.lucas.init.*;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ClientModInitializer;

@Environment(EnvType.CLIENT)
public class LucasModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Start of user code block mod constructor
		// End of user code block mod constructor
		LucasModModels.clientLoad();
		LucasModBlocksRenderers.clientLoad();

		LucasModEntityRenderers.clientLoad();
		LucasModParticles.clientLoad();

		LucasModScreens.clientLoad();
		LucasModMenus.clientLoad();

		ClientPlayNetworking.registerGlobalReceiver(LucasModVariables.SavedDataSyncMessage.TYPE, LucasModVariables.SavedDataSyncMessage::handleData);
		// Start of user code block mod init
		// End of user code block mod init
	}
	// Start of user code block mod methods
	// End of user code block mod methods
}