package net.mcreator.lucas.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.lucas.entity.SheepMob1Entity;
import net.mcreator.lucas.client.model.Modelsupersheep;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class SheepMob1Renderer extends MobRenderer<SheepMob1Entity, LivingEntityRenderState, Modelsupersheep> {
	private SheepMob1Entity entity = null;

	public SheepMob1Renderer(EntityRendererProvider.Context context) {
		super(context, new Modelsupersheep(context.bakeLayer(Modelsupersheep.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(SheepMob1Entity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("lucas:textures/entities/supersheeptexture.png");
	}
}