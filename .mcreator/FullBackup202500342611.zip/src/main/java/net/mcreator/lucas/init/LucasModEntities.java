/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.lucas.entity.SuperSheepEntity;
import net.mcreator.lucas.entity.SheepMob1Entity;
import net.mcreator.lucas.entity.DumbcarEntity;
import net.mcreator.lucas.LucasMod;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

public class LucasModEntities {
	public static EntityType<SheepMob1Entity> SHEEP_MOB_1;
	public static EntityType<SuperSheepEntity> SUPER_SHEEP;
	public static EntityType<DumbcarEntity> DUMBCAR;

	public static void load() {
		SHEEP_MOB_1 = register("sheep_mob_1", EntityType.Builder.<SheepMob1Entity>of(SheepMob1Entity::new, MobCategory.MONSTER).clientTrackingRange(50).updateInterval(3)

				.sized(0.6f, 1.8f));
		SUPER_SHEEP = register("super_sheep", EntityType.Builder.<SuperSheepEntity>of(SuperSheepEntity::new, MobCategory.MONSTER).clientTrackingRange(99).updateInterval(3)

				.sized(0.6f, 1.8f));
		DUMBCAR = register("dumbcar", EntityType.Builder.<DumbcarEntity>of(DumbcarEntity::new, MobCategory.MONSTER).clientTrackingRange(64).updateInterval(3)

				.sized(0.6f, 1.8f));
		init();
		registerAttributes();
	}

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(LucasMod.MODID, registryname),
				(EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(LucasMod.MODID, registryname))));
	}

	public static void init() {
		SheepMob1Entity.init();
		DumbcarEntity.init();
	}

	public static void registerAttributes() {
		FabricDefaultAttributeRegistry.register(SHEEP_MOB_1, SheepMob1Entity.createAttributes());
		FabricDefaultAttributeRegistry.register(SUPER_SHEEP, SuperSheepEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(DUMBCAR, DumbcarEntity.createAttributes());
	}
}