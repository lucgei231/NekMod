package net.mcreator.lucas.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;

public class HelloBabyRedstoneOnProcedure {
	public static boolean eventResult = true;

	public HelloBabyRedstoneOnProcedure() {
		ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
			execute(sender.level(), sender.getX(), sender.getY(), sender.getZ());
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof Level _level && !_level.isClientSide()) {
			_level.explode(null, x, y, z, 50, Level.ExplosionInteraction.TNT);
		}
		if (world instanceof ServerLevel _level) {
			LightningBolt entityToSpawn_1 = EntityType.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
			entityToSpawn_1.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
			entityToSpawn_1.setVisualOnly(true);
			_level.addFreshEntity(entityToSpawn_1);
		}
	}
}