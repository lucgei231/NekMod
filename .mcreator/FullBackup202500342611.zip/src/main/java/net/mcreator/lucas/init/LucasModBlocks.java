/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.lucas.block.*;
import net.mcreator.lucas.LucasMod;

import java.util.function.Function;

public class LucasModBlocks {
	public static Block HELLO_BABY;
	public static Block JUMPBLOCK;
	public static Block FIREBLOCK;
	public static Block BIGFIRE;
	public static Block IRIDIUMORE;
	public static Block LOOCLOUD;
	public static Block DUMB_BUTT_LOO_PLANT;

	public static void load() {
		HELLO_BABY = register("hello_baby", HelloBabyBlock::new);
		JUMPBLOCK = register("jumpblock", JumpblockBlock::new);
		FIREBLOCK = register("fireblock", FireblockBlock::new);
		BIGFIRE = register("bigfire", BigfireBlock::new);
		IRIDIUMORE = register("iridiumore", IridiumoreBlock::new);
		LOOCLOUD = register("loocloud", LoocloudBlock::new);
		DUMB_BUTT_LOO_PLANT = register("dumb_butt_loo_plant", DumbButtLooPlantBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> B register(String name, Function<BlockBehaviour.Properties, B> supplier) {
		return (B) Blocks.register(ResourceKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath(LucasMod.MODID, name)), (Function<BlockBehaviour.Properties, Block>) supplier, BlockBehaviour.Properties.of());
	}
}