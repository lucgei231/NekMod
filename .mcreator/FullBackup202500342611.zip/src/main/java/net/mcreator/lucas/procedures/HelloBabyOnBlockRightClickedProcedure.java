package net.mcreator.lucas.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

public class HelloBabyOnBlockRightClickedProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Warning: bats Warning:bats"), false);
		}
		for (int index0 = 0; index0 < 50; index0++) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn_1 = EntityType.BAT.spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn_1 != null) {
					entityToSpawn_1.setYRot(world.getRandom().nextFloat() * 360F);
				}
				LightningBolt entityToSpawn_2 = EntityType.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
				entityToSpawn_2.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, 0, z)));
				entityToSpawn_2.setVisualOnly(true);
				_level.addFreshEntity(entityToSpawn_2);
			}
		}
		if (world instanceof Level _level && !_level.isClientSide()) {
			_level.explode(null, x, y, z, 50, Level.ExplosionInteraction.TNT);
		}
	}
}