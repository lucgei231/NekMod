/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.Registry;

import net.mcreator.lucas.LucasMod;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;

public class LucasModParticleTypes {
	public static SimpleParticleType LOO;

	public static void load() {
		register("loo", FabricParticleTypes.simple());
	}

	private static SimpleParticleType register(String registryname, SimpleParticleType element) {
		return Registry.register(BuiltInRegistries.PARTICLE_TYPE, ResourceLocation.fromNamespaceAndPath(LucasMod.MODID, registryname), element);
	}
}