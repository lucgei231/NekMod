/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.lucas.item.LightningswordItem;
import net.mcreator.lucas.item.IrItem;
import net.mcreator.lucas.LucasMod;

import java.util.function.Function;

public class LucasModItems {
	public static Item HELLO_BABY;
	public static Item JUMPBLOCK;
	public static Item FIREBALL_SWORD;
	public static Item FIREBLOCK;
	public static Item BIGFIRE;
	public static Item IRIDIUMORE;
	public static Item IR;
	public static Item SHEEP_MOB_1_SPAWN_EGG;
	public static Item SUPER_SHEEP_SPAWN_EGG;
	public static Item LOOCLOUD;
	public static Item DUMB_BUTT_LOO_PLANT;
	public static Item DUMBCAR_SPAWN_EGG;

	public static void load() {
		HELLO_BABY = block(LucasModBlocks.HELLO_BABY, "hello_baby");
		JUMPBLOCK = block(LucasModBlocks.JUMPBLOCK, "jumpblock");
		FIREBALL_SWORD = register("fireball_sword", LightningswordItem::new);
		FIREBLOCK = block(LucasModBlocks.FIREBLOCK, "fireblock");
		BIGFIRE = block(LucasModBlocks.BIGFIRE, "bigfire");
		IRIDIUMORE = block(LucasModBlocks.IRIDIUMORE, "iridiumore");
		IR = register("ir", IrItem::new);
		SHEEP_MOB_1_SPAWN_EGG = register("sheep_mob_1_spawn_egg", properties -> new SpawnEggItem(LucasModEntities.SHEEP_MOB_1, properties));
		SUPER_SHEEP_SPAWN_EGG = register("super_sheep_spawn_egg", properties -> new SpawnEggItem(LucasModEntities.SUPER_SHEEP, properties));
		LOOCLOUD = block(LucasModBlocks.LOOCLOUD, "loocloud");
		DUMB_BUTT_LOO_PLANT = block(LucasModBlocks.DUMB_BUTT_LOO_PLANT, "dumb_butt_loo_plant");
		DUMBCAR_SPAWN_EGG = register("dumbcar_spawn_egg", properties -> new SpawnEggItem(LucasModEntities.DUMBCAR, properties));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		return (I) Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(LucasMod.MODID, name)), (Function<Item.Properties, Item>) supplier);
	}

	private static Item block(Block block, String name) {
		return block(block, name, new Item.Properties());
	}

	private static Item block(Block block, String name, Item.Properties properties) {
		return Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(LucasMod.MODID, name)), prop -> new BlockItem(block, prop), properties);
	}
}