/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.mcreator.lucas.procedures.LightningswordRightclicked1Procedure;
import net.mcreator.lucas.procedures.LightningswordLivingEntityIsHitWithToolProcedure;
import net.mcreator.lucas.procedures.IridiumoreBlockDestroyedByPlayerProcedure;
import net.mcreator.lucas.procedures.HelloBabyRedstoneOnProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class LucasModProcedures {
	public static void load() {
		new HelloBabyRedstoneOnProcedure();
		new LightningswordLivingEntityIsHitWithToolProcedure();
		new LightningswordRightclicked1Procedure();
		new IridiumoreBlockDestroyedByPlayerProcedure();
	}
}