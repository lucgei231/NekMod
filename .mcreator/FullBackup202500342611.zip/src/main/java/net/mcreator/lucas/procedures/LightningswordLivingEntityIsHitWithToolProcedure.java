package net.mcreator.lucas.procedures;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

public class LightningswordLivingEntityIsHitWithToolProcedure {
	public static boolean eventResult = true;

	public LightningswordLivingEntityIsHitWithToolProcedure() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, damageSource, amount) -> {
			if (entity != null) {
				execute();
			}
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute() {
	}
}