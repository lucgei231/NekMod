/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.lucas.LucasMod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class LucasModTabs {
	public static ResourceKey<CreativeModeTab> TAB_NEK_MOD = ResourceKey.create(Registries.CREATIVE_MODE_TAB, ResourceLocation.fromNamespaceAndPath(LucasMod.MODID, "nek_mod"));

	public static void load() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_NEK_MOD,
				FabricItemGroup.builder().title(Component.translatable("item_group.lucas.nek_mod")).icon(() -> new ItemStack(LucasModBlocks.HELLO_BABY)).displayItems((parameters, tabData) -> {
					tabData.accept(LucasModBlocks.HELLO_BABY.asItem());
					tabData.accept(LucasModBlocks.JUMPBLOCK.asItem());
					tabData.accept(LucasModItems.FIREBALL_SWORD);
					tabData.accept(LucasModBlocks.FIREBLOCK.asItem());
					tabData.accept(LucasModBlocks.BIGFIRE.asItem());
					tabData.accept(LucasModBlocks.IRIDIUMORE.asItem());
					tabData.accept(LucasModItems.IR);
					tabData.accept(LucasModItems.SHEEP_MOB_1_SPAWN_EGG);
					tabData.accept(LucasModItems.SUPER_SHEEP_SPAWN_EGG);
					tabData.accept(LucasModBlocks.LOOCLOUD.asItem());
					tabData.accept(LucasModBlocks.DUMB_BUTT_LOO_PLANT.asItem());
					tabData.accept(LucasModItems.DUMBCAR_SPAWN_EGG);
				}).build());
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tabData -> {
			tabData.accept(LucasModBlocks.HELLO_BABY.asItem());
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(tabData -> {
			tabData.accept(LucasModBlocks.JUMPBLOCK.asItem());
			tabData.accept(LucasModBlocks.FIREBLOCK.asItem());
			tabData.accept(LucasModBlocks.BIGFIRE.asItem());
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(tabData -> {
			tabData.accept(LucasModItems.FIREBALL_SWORD);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(tabData -> {
			tabData.accept(LucasModBlocks.IRIDIUMORE.asItem());
			tabData.accept(LucasModItems.IR);
			tabData.accept(LucasModBlocks.LOOCLOUD.asItem());
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS).register(tabData -> {
			tabData.accept(LucasModItems.SHEEP_MOB_1_SPAWN_EGG);
			tabData.accept(LucasModItems.SUPER_SHEEP_SPAWN_EGG);
			tabData.accept(LucasModItems.DUMBCAR_SPAWN_EGG);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.NATURAL_BLOCKS).register(tabData -> {
			tabData.accept(LucasModBlocks.DUMB_BUTT_LOO_PLANT.asItem());
		});
	}
}