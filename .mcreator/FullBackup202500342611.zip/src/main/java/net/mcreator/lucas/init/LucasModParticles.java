/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lucas.init;

import net.mcreator.lucas.client.particle.LooParticle;

import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class LucasModParticles {
	public static void clientLoad() {
		ParticleFactoryRegistry.getInstance().register(LucasModParticleTypes.LOO, LooParticle::provider);
	}
}